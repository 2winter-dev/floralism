

export default function CancelPage(){
    return (<div>
       false
    </div>)
}