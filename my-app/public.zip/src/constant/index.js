export const constant={
    // api_url:'http://192.168.1.24:6353'
    // api_url:'http://192.168.31.134:6353'
    api_url:'http://admin.floralismhk.com'
}